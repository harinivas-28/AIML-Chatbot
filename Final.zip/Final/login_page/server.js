// npm init -y
// npm i express
// npm i mongoose

const fs = require("node:fs")  // Used For handling Files
const express = require("express")  
const multer = require("multer"); // Used as Storage 
const mongoose = require("mongoose") // To Connect to MongoDB
const app = express()
const port = 3000 
app.use(express.static('public')); // Using Express
const bcrypt = require('bcrypt'); // Used For Hashing Passwords
const session = require('express-session'); // Used for Sessions
app.set('view engine', 'ejs'); // Adjust 'ejs' to your chosen template engine


const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB limit
});

app.use(session({
  secret: 'your-secret-key',
  resave: true,
  saveUninitialized: true
}));


const User = require("./model/user") // Loading Schema for MongoDB in user.js

app.use(express.urlencoded({extended: true}))

mongoose.connect("mongodb://localhost:27017/projectDataDB").
then(()=>{
  console.log("Database Connected to: mongodb://localhost:27017")
}).catch((e)=>{
  console.log(e)
  console.log("Database Can't Be Connected")
})

app.get("/", (req, res)=>{
  res.sendFile(__dirname + '/Final/index.html');
})

app.post("/signup", upload.single("avatar"), async (req, res) => {
  try {
    // Check if a file is provided
    if (!req.file) {
      return res.status(400).send("No file uploaded.");
    }

    // Check if the username already exists
    const existingUser = await User.findOne({ username: req.body.username });
    if (existingUser) {
      // User with the same username already exists
      return res.status(400).send('<script>alert("Username already exists. Please choose a different username."); window.location.href="/signup";</script>');
    }

    // Create a new user with the provided data
    const userData = new User({
      username: req.body.username,
      email: req.body.mail,
      password: req.body.password,
      avatar: {
        data: req.file.buffer,
        contentType: req.file.mimetype
      }
    });

    // Hash the password before saving
    const chilliRounds = 10;
    userData.password = await bcrypt.hash(req.body.password, chilliRounds);

    // Save the new user to the database
    await userData.save();

    // Redirect to the login page
    res.sendFile(__dirname + '/views/login.html');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});



app.post('/login', async (req, res) => {
  const username = req.body.username
  const password = req.body.password
  try {
    const user = await User.findOne({ username });

    if (user && await bcrypt.compare(password, user.password)) {
      // Successful login
      req.session.user = { id: user._id, username: user.username };
      res.sendFile(__dirname + '/Final/index.html');
    } else {
      // Invalid credentials
      console.log("Invalid Credentials");
      res.status(401).sendFile(__dirname + '/views/login.html');
      res.write('<script>alert("Invalid Credentials"); window.location.href="/login";</script>');
      res.end();
    }
  } catch (error) {
    console.log(error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/profile', async (req, res) => {
  // Check if user is logged in
  if (req.session.user) {
    try {
      // Fetch user details including the avatar from the database
      const user = await User.findById(req.session.user.id);

      if (user) {
        // Render the profile page with user details
        res.render('profile', { username: user.username, avatar: user.avatar });
      } else {
        res.status(404).send('User not found');
      }
    } catch (error) {
      console.error(error);
      res.status(500).send('Error fetching user details.');
    }
  } else {
    res.redirect('/login'); // Redirect to login if not logged in
  }
});

app.get('/logout', (req, res) => {
  // Destroy the session
  req.session.destroy((err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error during logout.');
    } else {
      res.redirect('/login'); // Redirect to login after logout
    }
  });
});

app.get('/style.css',(req,res)=>{
  res.sendFile(__dirname + '/views/style.css')
})

app.get('/app.js',(req,res)=>{
  res.sendFile(__dirname + '/views/app.js')
})

app.get('/assets/css/clash-display.css',(req,res)=>{
  res.sendFile(__dirname + '/Final/assets/css/clash-display.css')
})

app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/views/login.html');
}
);

app.get("/signup", (req, res)=>{
  res.sendFile(__dirname + '/views/login.html');
})

app.get("/assets/css/style.css", (req, res)=>{
  res.sendFile(__dirname + '/Final/assets/css/style.css');
})


app.get("/chatbot", (req, res)=>{
  res.sendFile(__dirname + '/Final/botpage.html');
})

app.get("/assets/css/style.css", (req, res)=>{
  res.sendFile(__dirname + '/Final/assets/css/style.css');
})

app.get("/myscript.js", (req, res)=>{
  res.sendFile(__dirname + '/Final/myscript.js');
})

app.listen(port, ()=>{
    console.log("App Running on port: ", port)
    console.log(`Server is running at http://localhost:${port}`);
})


