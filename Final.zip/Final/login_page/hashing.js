async function hashPassword(password) {
    // Generate a random salt
    const salt = crypto.getRandomValues(new Uint8Array(16));
  
    // Convert the password and salt to ArrayBuffer
    const passwordBuffer = new TextEncoder().encode(password);
    const saltBuffer = new Uint8Array(salt);
  
    // Concatenate the password and salt
    const combinedBuffer = new Uint8Array(passwordBuffer.length + saltBuffer.length);
    combinedBuffer.set(passwordBuffer);
    combinedBuffer.set(saltBuffer, passwordBuffer.length);
  
    // Hash the combined buffer using SHA-256
    const hashBuffer = await crypto.subtle.digest('SHA-256', combinedBuffer);
  
    // Convert the hash buffer to a hex-encoded string
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashedPassword = hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');
  
    // Return the salt and hashed password
    return { salt, hashedPassword };
  }
  
  // Example usage
  const password = 'Chintug2870';
  hashPassword(password).then(result => {
    console.log('Salt:', result.salt);
    console.log('Hashed Password:', result.hashedPassword);
  });
  