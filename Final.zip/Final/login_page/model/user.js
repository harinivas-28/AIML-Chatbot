
const mongoose = require("mongoose")

const projectData = new mongoose.Schema({
    username: String,
    email:String,
  password: String,
  avatar: {
    data: Buffer,
    contentType: String
    }
}
) 
  
  const User = mongoose.model("User", projectData);
  module.exports = User;